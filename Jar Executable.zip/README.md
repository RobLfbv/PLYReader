A NOTER :
Nous avons suivi les instruction disponible sur Moodle pour générer le .jar (non sans difficultés...)
Néanmoins, notre .jar ne semble s'executer que s'il est dans le dossier target avec les dépendances du jar à coté
Pourtant nous avons bien compilé comme suit : "mvn package"
Nous avons déjà eu du mal à installer Maven pour pouvoir executer la command mvn (chose que nous avons pas trouvé sur Moodle)
En esperant que cela convienne tout de même.
